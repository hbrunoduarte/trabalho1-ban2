package com.duarte.imobiliaria.controllers;

import com.duarte.imobiliaria.controllers.DTO.ContratoPainelDTO;
import com.duarte.imobiliaria.controllers.DTO.FiltroReciboDTO;
import com.duarte.imobiliaria.controllers.DTO.ReciboPainelDTO;
import com.duarte.imobiliaria.controllers.DTO.VisitaPainelDTO;
import com.duarte.imobiliaria.controllers.session.TipoUsuarioLogado;
import com.duarte.imobiliaria.database.interfaceDAO.ContratoLocacaoDAO;
import com.duarte.imobiliaria.database.interfaceDAO.ContratoVendaDAO;
import com.duarte.imobiliaria.database.interfaceDAO.ReciboDAO;
import com.duarte.imobiliaria.database.interfaceDAO.VisitaAgendadaDAO;
import com.duarte.imobiliaria.model.ContratoLocacao;
import com.duarte.imobiliaria.model.ContratoVenda;
import com.duarte.imobiliaria.model.ReciboAluguel;
import com.duarte.imobiliaria.model.VisitaAgendada;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static com.duarte.imobiliaria.controllers.session.UsuarioLogado.getIdUsuario;
import static com.duarte.imobiliaria.controllers.session.UsuarioLogado.isCliente;

@RestController
@RequestMapping("/api/painel/cliente")
public class PainelClienteController {

    private final VisitaAgendadaDAO visitaDAO;
    private final ContratoVendaDAO vendaDAO;
    private final ContratoLocacaoDAO locacaoDAO;
    private final ReciboDAO reciboDAO;

    public PainelClienteController(VisitaAgendadaDAO visitaDAO, ContratoVendaDAO vendaDAO, ContratoLocacaoDAO locacaoDAO, ReciboDAO reciboDAO) {
        this.visitaDAO = visitaDAO;
        this.vendaDAO = vendaDAO;
        this.locacaoDAO = locacaoDAO;
        this.reciboDAO = reciboDAO;
    }

    @GetMapping("/visitas")
    public ResponseEntity<List<VisitaPainelDTO>> listarVisitas(HttpSession sessao) {

        if (!isCliente(sessao)) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        List<VisitaAgendada> visitas = visitaDAO.buscarPorId(getIdUsuario(sessao), true, false, TipoUsuarioLogado.CLIENTE);
        return ResponseEntity.ok(visitas.stream().map(VisitaAgendada::getPainelDTO).toList());
    }

    @GetMapping("/contratos")
    public ResponseEntity<List<ContratoPainelDTO>> listarContratos(HttpSession sessao) {

        if (!isCliente(sessao)) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        List<ContratoLocacao> locacoes = locacaoDAO.buscarPorId(getIdUsuario(sessao), TipoUsuarioLogado.CLIENTE, true);
        List<ContratoVenda> vendas = vendaDAO.buscarPorId(getIdUsuario(sessao), TipoUsuarioLogado.CLIENTE, true);
        List<ContratoPainelDTO> contratos = new ArrayList<>(locacoes.size() + vendas.size());
        contratos.addAll(locacoes.stream().map(ContratoLocacao::getDTO).toList());
        contratos.addAll(vendas.stream().map(ContratoVenda::getDTO).toList());
        return ResponseEntity.ok(contratos);
    }

    @GetMapping("/contratos/locacao/{idLocacao}/recibos")
    public ResponseEntity<List<ReciboPainelDTO>> listarRecibos(@PathVariable int idLocacao, @Valid FiltroReciboDTO filtro, HttpSession sessao) {

        if (!isCliente(sessao)) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        Optional<ContratoLocacao> locacao = locacaoDAO.buscarPorId(idLocacao);
        if (locacao.isEmpty()) return ResponseEntity.badRequest().build();
        if (locacao.get().getCliente().getIdCliente() != getIdUsuario(sessao)) return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();

        List<ReciboAluguel> recibos = reciboDAO.filtrar(filtro);

        return ResponseEntity.ok(recibos.stream().map(ReciboAluguel::getDTO).toList());
    }
}
