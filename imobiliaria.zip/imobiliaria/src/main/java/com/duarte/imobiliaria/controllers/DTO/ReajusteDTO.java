package com.duarte.imobiliaria.controllers.DTO;

import java.math.BigDecimal;

public class ReajusteDTO {

    private BigDecimal novoValor;
    private String indiceUtilizado;

    public BigDecimal getNovoValor() {
        return novoValor;
    }

    public void setNovoValor(BigDecimal novoValor) {
        this.novoValor = novoValor;
    }

    public String getIndiceUtilizado() {
        return indiceUtilizado;
    }

    public void setIndiceUtilizado(String indiceUtilizado) {
        this.indiceUtilizado = indiceUtilizado;
    }
}
