package com.duarte.imobiliaria.database.interfaceDAO;

import com.duarte.imobiliaria.controllers.session.TipoUsuarioLogado;
import com.duarte.imobiliaria.model.ContratoLocacao;

import java.util.List;
import java.util.Optional;

public interface ContratoLocacaoDAO {
    void salvar(ContratoLocacao contrato);
    Optional<ContratoLocacao> buscarPorId(int id);
    List<ContratoLocacao> buscarPorId(int id, TipoUsuarioLogado t, boolean maisRecente);
    List<ContratoLocacao> listarTodos();
}
