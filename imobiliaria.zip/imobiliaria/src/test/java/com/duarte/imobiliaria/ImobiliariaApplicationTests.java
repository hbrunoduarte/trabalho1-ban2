package com.duarte.imobiliaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImobiliariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
